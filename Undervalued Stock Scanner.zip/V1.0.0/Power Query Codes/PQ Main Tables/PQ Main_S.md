### Power Query Code for Main_L table:
The dynamic path for **Undervalued Stock Scanner** folder is in the "DynamicPath" table, within the **Dynamic Path** sheet.  
**Main_S Function** is used to apply data transformation to a list of all csv files in **Downloaded CSV Files** folder. This creates **Main_S** tables for all sectors.
```m
let
    Source = Excel.CurrentWorkbook(){[Name="DynamicPath"]}[Content],
    Path = Source{0}[Path],
    Files = Folder.Files(Path & "Downloaded CSV Files"),
    #"Removed Other Columns" = Table.SelectColumns(Files,{"Name"}),
    #"Invoked Custom Function" = Table.AddColumn(#"Removed Other Columns", "Main_S Function", each #"Main_S Function"([Name])),
    #"Main_S Function1" = #"Invoked Custom Function"{0}[Main_S Function]
in
    #"Main_S Function1"
```
The "Main_S Function1" step expands one of the tables created by Main_S Funtcion. The expanded table in this code corresponds to "Builder Sample.csv".  
To switch to another sector's "Main_S" table, undo the "Main_S Function1" step and choose another table corresponding to the desired sector.