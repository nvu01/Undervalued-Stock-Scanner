### Current Price column in main tables
```
let
    Current_Price = () => ("=RTD(""tos.rtd"", , ""LAST"", [@Symbol])")
in
    Current_Price
```
### P/FCF column in main tables
```
let
    PFCF = () => ("=IF(ISNUMBER([@[Free CF]]),IF([@[Free CF]]<>0,[@[Current Price]]/[@[Free CF]],""""),"""")")
in
    PFCF 
 ```
### P/BV column in main tables
```
let
    PBV = () => ("=IF(ISNUMBER([@BVPS]),IF([@BVPS]<>0,[@[Current Price]]/[@BVPS],""""),"""")")
in
    PBV
```
### P/E column in main tables
```
let
    PE = () => ("=IF(ISNUMBER([@EPS]),IF([@EPS]<>0,[@[Current Price]]/[@EPS],""""),"""")")
in
    PE
```

### PRELIMINARY CRITERIA COLUMNS

#### L_Preliminary Criteria
```
let
    Preliminary_L = () => ("=IF(AND([@[P/FCF]]>0, [@[P/FCF]]<VLOOKUP([@Industry], Mean_PFCF_L, 2, FALSE), [@[P/BV]]>0,  [@[P/BV]]<VLOOKUP([@Industry], Mean_PBV_L, 2, FALSE), [@ROE]>10, [@ROA]>5, [@[A/E]]>1, [@[A/E]]<VLOOKUP([@Industry], Mean_AE_L, 2, FALSE)), ""YES"", ""NO"")")
in
    Preliminary_L
```
#### M_Preliminary Criteria
```
let
    Preliminary_M = () => ("=IF(AND([@[P/FCF]]>0, [@[P/FCF]]<VLOOKUP([@Industry], Mean_PFCF_M, 2, FALSE), [@[P/BV]]>0,  [@[P/BV]]<VLOOKUP([@Industry], Mean_PBV_M, 2, FALSE), [@ROE]>10, [@ROA]>5, [@[A/E]]>1, [@[A/E]]<VLOOKUP([@Industry], Mean_AE_M, 2, FALSE)), ""YES"", ""NO"")")
in
    Preliminary_M
```
#### S_Preliminary Criteria
```
let
    Preliminary_S = () => ("=IF(AND([@[P/FCF]]>0, [@[P/FCF]]<VLOOKUP([@Industry], Mean_PFCF_S, 2, FALSE), [@[P/BV]]>0,  [@[P/BV]]<VLOOKUP([@Industry], Mean_PBV_S, 2, FALSE), [@ROE]>10, [@ROA]>5, [@[A/E]]>1, [@[A/E]]<VLOOKUP([@Industry], Mean_AE_S, 2, FALSE)), ""YES"", ""NO"")")
in
    Preliminary_S
```

#### Z SCORE COLUMNS IN MAIN_L

#### L_P/FCF Z Score:
```
let
    PFCF_ZS_L = () => ("=([@[P/FCF]]-VLOOKUP([@Industry], Mean_PFCF_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_PFCF_L, 3, FALSE))")
in
    PFCF_ZS_L
```
#### L_P/BV Z Score:
```
let
    PBV_ZS_L = () => ("=([@[P/BV]]-VLOOKUP([@Industry], Mean_PBV_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_PBV_L, 3, FALSE))")
in
    PBV_ZS_L
```
#### L_ROE Z Score:
```
let
    ROE_ZS_L = () => ("=([@ROE]-VLOOKUP([@Industry], Mean_ROE_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROE_L, 3, FALSE))")
in
    ROE_ZS_L
```
#### L_ROA Z Score:
```
let
    ROA_ZS_L = () => ("=([@ROA]-VLOOKUP([@Industry], Mean_ROA_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROA_L, 3, FALSE))")
in
    ROA_ZS_L
```
#### L_P/E Z Score:
```
let
    PE_ZS_L = () => ("=([@[P/E]]-VLOOKUP([@Industry], Mean_PE_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_PE_L, 3, FALSE))")
in
    PE_ZS_L
```
#### L_A/E Z Score:
```
let
    AE_ZS_L = () => ("=([@[A/E]]-VLOOKUP([@Industry], Mean_AE_L, 2, FALSE))/(VLOOKUP([@Industry], Mean_AE_L, 3, FALSE))")
in
    AE_ZS_L
```

### OUTLIER COLUMNS IN MAIN_L

#### L_P/FCF Outlier:
```
let
    PFCF_Outlier_L = () => ("=IF(OR([@[P/FCF]]<XLOOKUP([@Industry], Quartile_L[Industry], Quartile_L[P/FCF LB]), [@[P/FCF]]>XLOOKUP([@Industry], Quartile_L[Industry], Quartile_L[P/FCF UB])), ""Yes"", ""No"")")
in
    PFCF_Outlier_L
```
#### L_P/BV Outlier:
```
let
    PBV_Outlier_L = () => ("=IF(OR([@[P/BV]]<XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[P/BV LB]),[@[P/BV]]>XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[P/BV UB])),""Yes"",""No"")")
in
    PBV_Outlier_L
```
#### L_ROE Outlier:
```
let
    ROE_Outlier_L = () => ("=IF(OR([@ROE]<XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[ROE LB]),[@ROE]>XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[ROE UB])),""Yes"",""No"")")
in
    ROE_Outlier_L
```
#### L_ROA Outlier:
```
let
    ROA_Outlier_L = () => ("=IF(OR([@ROA]<XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[ROA LB]),[@ROA]>XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[ROA UB])),""Yes"",""No"")")
in
    ROA_Outlier_L
```
#### L_P/E Outlier:
```
let
    PE_Outlier_L = () => ("=IF(OR([@[P/E]]<XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[P/E LB]),[@[P/E]]>XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[P/E UB])),""Yes"",""No"")")
in
    PE_Outlier_L
```
#### L_A/E Outlier:
```
let
    AE_Outlier_L = () => ("=IF(OR([@[A/E]]<XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[A/E LB]),[@[A/E]]>XLOOKUP([@Industry],Quartile_L[Industry],Quartile_L[A/E UB])),""Yes"",""No"")")
in
    AE_Outlier_L
```

### Z SCORE COLUMNS IN MAIN_M

#### M_P/FCF Z Score:
```
let
    PFCF_ZS_M = () => ("=([@[P/FCF]]-VLOOKUP([@Industry], Mean_PFCF_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_PFCF_M, 3, FALSE))")
in
    PFCF_ZS_M
```
#### M_P/BV Z Score:
```
let
    PBV_ZS_M = () => ("=([@[P/BV]]-VLOOKUP([@Industry], Mean_PBV_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_PBV_M, 3, FALSE))")
in
    PBV_ZS_M
```
#### M_ROE Z Score:
```
let
    ROE_ZS_M = () => ("=([@ROE]-VLOOKUP([@Industry], Mean_ROE_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROE_M, 3, FALSE))")
in
    ROE_ZS_M
```
#### M_ROA Z Score:
```
let
    ROA_ZS_M = () => ("=([@ROA]-VLOOKUP([@Industry], Mean_ROA_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROA_M, 3, FALSE))")
in
    ROA_ZS_M
```
#### M_P/E Z Score:
```
let
    PE_ZS_M = () => ("=([@[P/E]]-VLOOKUP([@Industry], Mean_PE_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_PE_M, 3, FALSE))")
in
    PE_ZS_M
```
#### M_A/E Z Score:
```
let
    AE_ZS_M = () => ("=([@[A/E]]-VLOOKUP([@Industry], Mean_AE_M, 2, FALSE))/(VLOOKUP([@Industry], Mean_AE_M, 3, FALSE))")
in
    AE_ZS_M
```

### OUTLIER COLUMNS IN MAIN_M

#### M_P/FCF Outlier:
```
let
    PFCF_Outlier_M = () => ("=IF(OR([@[P/FCF]]<XLOOKUP([@Industry], Quartile_M[Industry], Quartile_M[P/FCF LB]), [@[P/FCF]]>XLOOKUP([@Industry], Quartile_M[Industry], Quartile_M[P/FCF UB])), ""Yes"", ""No"")")
in
    PFCF_Outlier_M
```
#### M_P/BV Outlier:
```
let
    PBV_Outlier_M = () => ("=IF(OR([@[P/BV]]<XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[P/BV LB]),[@[P/BV]]>XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[P/BV UB])),""Yes"",""No"")")
in
    PBV_Outlier_M
```
#### M_ROE Outlier:
```
let
    ROE_Outlier_M = () => ("=IF(OR([@ROE]<XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[ROE LB]),[@ROE]>XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[ROE UB])),""Yes"",""No"")")
in
    ROE_Outlier_M
```
#### M_ROA Outlier:
```
let
    ROA_Outlier_M = () => ("=IF(OR([@ROA]<XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[ROA LB]),[@ROA]>XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[ROA UB])),""Yes"",""No"")")
in
    ROA_Outlier_M
```
#### M_P/E Outlier:
```
let
    PE_Outlier_M = () => ("=IF(OR([@[P/E]]<XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[P/E LB]),[@[P/E]]>XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[P/E UB])),""Yes"",""No"")")
in
    PE_Outlier_M
```
#### M_A/E Outlier:
```
let
    AE_Outlier_M = () => ("=IF(OR([@[A/E]]<XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[A/E LB]),[@[A/E]]>XLOOKUP([@Industry],Quartile_M[Industry],Quartile_M[A/E UB])),""Yes"",""No"")")
in
    AE_Outlier_M
```

### Z SCORE COLUMNS IN MAIN_S

#### S_P/FCF Z Score:
```
let
    PFCF_ZS_S = () => ("=([@[P/FCF]]-VLOOKUP([@Industry], Mean_PFCF_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_PFCF_S, 3, FALSE))")
in
    PFCF_ZS_S
```
#### S_P/BV Z Score:
```
let
    PBV_ZS_S = () => ("=([@[P/BV]]-VLOOKUP([@Industry], Mean_PBV_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_PBV_S, 3, FALSE))")
in
    PBV_ZS_S
```
#### S_ROE Z Score:
```
let
    ROE_ZS_S = () => ("=([@ROE]-VLOOKUP([@Industry], Mean_ROE_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROE_S, 3, FALSE))")
in
    ROE_ZS_S
```
#### S_ROA Z Score:
```
let
    ROA_ZS_S = () => ("=([@ROA]-VLOOKUP([@Industry], Mean_ROA_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_ROA_S, 3, FALSE))")
in
    ROA_ZS_S
```
#### S_P/E Z Score:
```
let
    PE_ZS_S = () => ("=([@[P/E]]-VLOOKUP([@Industry], Mean_PE_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_PE_S, 3, FALSE))")
in
    PE_ZS_S
```
#### S_A/E Z Score:
```
let
    AE_ZS_S = () => ("=([@[A/E]]-VLOOKUP([@Industry], Mean_AE_S, 2, FALSE))/(VLOOKUP([@Industry], Mean_AE_S, 3, FALSE))")
in
    AE_ZS_S
```

### OUTLIER COLUMNS IN MAIN_S

#### S_P/FCF Outlier:
```
let
    PFCF_Outlier_S = () => ("=IF(OR([@[P/FCF]]<XLOOKUP([@Industry], Quartile_S[Industry], Quartile_S[P/FCF LB]), [@[P/FCF]]>XLOOKUP([@Industry], Quartile_S[Industry], Quartile_S[P/FCF UB])), ""Yes"", ""No"")")
in
    PFCF_Outlier_S
```
#### S_P/BV Outlier:
```
let
    PBV_Outlier_S = () => ("=IF(OR([@[P/BV]]<XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[P/BV LB]),[@[P/BV]]>XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[P/BV UB])),""Yes"",""No"")")
in
    PBV_Outlier_S
```
#### S_ROE Outlier:
```
let
    ROE_Outlier_S = () => ("=IF(OR([@ROE]<XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[ROE LB]),[@ROE]>XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[ROE UB])),""Yes"",""No"")")
in
    ROE_Outlier_S
```
#### S_ROA Outlier:
```
let
    ROA_Outlier_S = () => ("=IF(OR([@ROA]<XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[ROA LB]),[@ROA]>XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[ROA UB])),""Yes"",""No"")")
in
    ROA_Outlier_S
```
#### S_P/E Outlier:
```
let
    PE_Outlier_S = () => ("=IF(OR([@[P/E]]<XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[P/E LB]),[@[P/E]]>XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[P/E UB])),""Yes"",""No"")")
in
    PE_Outlier_S
```
#### S_A/E Outlier:
```
let
    AE_Outlier_S = () => ("=IF(OR([@[A/E]]<XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[A/E LB]),[@[A/E]]>XLOOKUP([@Industry],Quartile_S[Industry],Quartile_S[A/E UB])),""Yes"",""No"")")
in
    AE_Outlier_S
```

