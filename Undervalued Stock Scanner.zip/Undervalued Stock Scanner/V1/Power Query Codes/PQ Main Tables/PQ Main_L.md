All new columns with Excel formulas are created through column functions.
```m
let
    Source = Csv.Document(File.Contents(FolderPath & "\Downloaded csv files\" & FileName & ".csv"),[Delimiter=",", Columns=10, Encoding=65001, QuoteStyle=QuoteStyle.None]),
    #"Removed Top Rows" = Table.Skip(Source,3),
    #"Promoted Headers" = Table.PromoteHeaders(#"Removed Top Rows", [PromoteAllScalars=true]),
    #"Removed Columns" = Table.RemoveColumns(#"Promoted Headers",{"Last"}),
    #"Extracted Text Before Delimiter" = Table.TransformColumns(#"Removed Columns", {{"Market Cap", each Text.BeforeDelimiter(_, " "), type text}}),
    #"Renamed Columns" = Table.RenameColumns(#"Extracted Text Before Delimiter",{{"Market Cap", "Market Cap (M)"}, {"Free Cash Flow Per Share - Current (LTM)", "Free CF"}, {"Book Value Per Share - Current (LTM)", "BVPS"}, {"Earnings Per Share - TTM - Current (LTM)", "EPS"}, {"Return on Equity (ROE) - Current (LTM)", "ROE"}, {"Return on Assets (ROA) - Current (LTM)", "ROA"}, {"Financial Leverage (Assets/Equity) - Current (LTM)", "A/E"}}),
    #"Replaced Value" = Table.ReplaceValue(#"Renamed Columns","<empty>",null,Replacer.ReplaceValue,{"Free CF", "BVPS", "EPS", "ROE", "ROA", "A/E"}),
    #"Changed Type" = Table.TransformColumnTypes(#"Replaced Value",{{"Free CF", type number}, {"BVPS", type number}, {"EPS", type number}, {"ROE", type number}, {"ROA", type number}, {"A/E", type number}, {"Market Cap (M)", Int64.Type}}),
    #"Rounded Off" = Table.TransformColumns(#"Changed Type",{{"Free CF", each Number.Round(_, 2), type number}, {"BVPS", each Number.Round(_, 2), type number}, {"EPS", each Number.Round(_, 2), type number}, {"ROE", each Number.Round(_, 2), type number}, {"ROA", each Number.Round(_, 2), type number}, {"A/E", each Number.Round(_, 2), type number}}),
    #"Added Conditional Column" = Table.AddColumn(#"Rounded Off", "Market Cap Category", each if [#"Market Cap (M)"] <= 2000 then "Small" else if [#"Market Cap (M)"] < 10000 then "Mid" else if [#"Market Cap (M)"] >= 10000 then "Large" else null),
    #"Invoked Custom Function" = Table.AddColumn(#"Added Conditional Column", "Current Price", each #"Current Price"()),
    #"Invoked Custom Function1" = Table.AddColumn(#"Invoked Custom Function", "P/FCF", each #"P/FCF"()),
    #"Invoked Custom Function2" = Table.AddColumn(#"Invoked Custom Function1", "P/BV", each #"P/BV"()),
    #"Invoked Custom Function3" = Table.AddColumn(#"Invoked Custom Function2", "P/E", each #"P/E"()),
    #"Reordered Columns" = Table.ReorderColumns(#"Invoked Custom Function3",{"Industry", "Symbol", "Market Cap (M)", "Current Price", "Free CF", "BVPS", "EPS", "P/FCF", "P/BV", "ROE", "ROA", "A/E", "P/E", "Market Cap Category"}),
    #"Grouped Rows" = Table.Group(#"Reordered Columns", {"Market Cap Category"}, {{"Table", each _, type table [Industry=nullable text, Symbol=nullable text, #"Market Cap (M)"=nullable number, Current Price=text, Free CF=number, BVPS=number, EPS=number, #"P/FCF"=text, #"P/BV"=text, ROE=number, ROA=number, #"P/E"=text, #"A/E"=number, Market Cap Category=text]}}),
    Large = #"Grouped Rows"{[#"Market Cap Category"="Large"]}[Table],
    #"Removed Columns1" = Table.RemoveColumns(Large,{"Market Cap Category"}),
    #"Invoked Custom Function4" = Table.AddColumn(#"Removed Columns1", "Preliminary Criteria", each #"L_Preliminary Criteria"()),
    #"Invoked Custom Function5" = Table.AddColumn(#"Invoked Custom Function4", "P/FCF Z Score", each #"L_P/FCF Z Score"()),
    #"Invoked Custom Function6" = Table.AddColumn(#"Invoked Custom Function5", "P/BV Z Score", each #"L_P/BV Z Score"()),
    #"Invoked Custom Function7" = Table.AddColumn(#"Invoked Custom Function6", "ROE Z Score", each #"L_ROE Z Score"()),
    #"Invoked Custom Function8" = Table.AddColumn(#"Invoked Custom Function7", "ROA Z Score", each #"L_ROA Z Score"()),
    #"Invoked Custom Function9" = Table.AddColumn(#"Invoked Custom Function8", "A/E Z Score", each #"L_A/E Z Score"()),
    #"Invoked Custom Function10" = Table.AddColumn(#"Invoked Custom Function9", "P/E Z Score", each #"L_P/E Z Score"()),
    #"Invoked Custom Function11" = Table.AddColumn(#"Invoked Custom Function10", "P/FCF Outlier", each #"L_P/FCF Outlier"()),
    #"Invoked Custom Function12" = Table.AddColumn(#"Invoked Custom Function11", "P/BV Outlier", each #"L_P/BV Outlier"()),
    #"Invoked Custom Function13" = Table.AddColumn(#"Invoked Custom Function12", "ROE Outlier", each #"L_ROE Outlier"()),
    #"Invoked Custom Function14" = Table.AddColumn(#"Invoked Custom Function13", "ROA Outlier", each #"L_ROA Outlier"()),
    #"Invoked Custom Function15" = Table.AddColumn(#"Invoked Custom Function14", "A/E Outlier", each #"L_A/E Outlier"()),
    #"Invoked Custom Function16" = Table.AddColumn(#"Invoked Custom Function15", "P/E Outlier", each #"L_P/E Outlier"())
in
    #"Invoked Custom Function16"
```