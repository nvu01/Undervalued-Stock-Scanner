### RESULT_L CONDITIONAL FORMAT

#### P/B
```
=$I7 < 0.7
=$I7 < 1
```
#### ROE
```
=$J7 > VLOOKUP($A7, Mean_ROE_L, 2, FALSE)
```
#### ROA
```
=$K7 > VLOOKUP($A7, Mean_ROA_L, 2, FALSE)
```
#### P/E
```
=AND($M7>1, $J7<25, $M7 < VLOOKUP($A7, Mean_PE_L, 2, FALSE))
=AND($M7>1, $M7<25)
=$M7 < VLOOKUP($A7, Mean_PE_L, 2, FALSE)
```

### RESULT_M CONDITIONAL FORMAT

#### P/B
```
=$I7 < 0.7
=$I7 < 1
```
#### ROE
```
=$J7 > VLOOKUP($A7, Mean_ROE_M, 2, FALSE)
```
#### ROA
```
=$K7 > VLOOKUP($A7, Mean_ROA_M, 2, FALSE)
```
#### P/E
```
=AND($M7>1, $M7<25, $M7 < VLOOKUP($A7, Mean_PE_M, 2, FALSE))
=AND($M7>1, $M7<25)
=$M7 < VLOOKUP($A7, Mean_PE_M, 2, FALSE)
```

### RESULT_S CONDITIONAL FORMAT

#### P/B
```
=$I7 < 0.7
=$I7 < 1
```
#### ROE
```
=$J7 > VLOOKUP($A7, Mean_ROE_S, 2, FALSE)
```
#### ROA
```
=$K7 > VLOOKUP($A7, Mean_ROA_S, 2, FALSE)
```
#### P/E
```
=AND($M7>1, $M7<25, $M7 < VLOOKUP($M7, Mean_PE_S, 2, FALSE))
=AND($M7>1, $M7<25)
=$M7 < VLOOKUP($A7, Mean_PE_S, 2, FALSE)

```

### Z SCORE COLUMNS CONDITIONAL FORMAT

#### P/FCF Z Score
```
=$N7<0
```
#### P/B Z Score
```
=$O7<0
```
#### ROE Z Score
```
=$P7>0
```
#### ROA Z Score
```
=$Q7>0
```
#### A/E Z Score
```
=$R7<0
```
#### P/E Z Score
```
=$S7<0

