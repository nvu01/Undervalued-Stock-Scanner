### Pull Data From Main Tables Based on Preliminary Criteria:

#### Result_L:
```
=FILTER(FILTER(Main_L, Main_L[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_L[#Headers]))
```
#### Result_M:
```
=FILTER(FILTER(Main_M, Main_M[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_M[#Headers]))
```
#### Result_S:
```
=FILTER(FILTER(Main_S, Main_S[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_S[#Headers]))
```

### Score Columns in Result Tables:

#### Result_L:
```
=SUM(IF($I7<1,1,0), IF($I7<0.7,1,0), IF($J7>VLOOKUP($A7, Mean_ROE_L, 2, FALSE),1,0), IF($K7>VLOOKUP($A7, Mean_ROA_L, 2,FALSE),1,0), IF($M7<1,1,0), IF($M7<VLOOKUP($A7, Mean_PE_L, 2, FALSE),1,0), IF(AND($M7>1,$M7<25),1,0))
```
#### Result_M:
```
=SUM(IF($I7<1,1,0), IF($I7<0.7,1,0), IF($J7>VLOOKUP($A7, Mean_ROE_M, 2, FALSE),1,0), IF($K7>VLOOKUP($A7, Mean_ROA_M, 2,FALSE),1,0), IF($M7<1,1,0), IF($M7<VLOOKUP($A7, Mean_PE_M, 2, FALSE),1,0), IF(AND($M7>1,$M7<25),1,0))
```
#### Result_S:
```
=SUM(IF($I7<1,1,0), IF($I7<0.7,1,0), IF($J7>VLOOKUP($A7, Mean_ROE_S, 2, FALSE),1,0), IF($K7>VLOOKUP($A7, Mean_ROA_S, 2,FALSE),1,0), IF($M7<1,1,0), IF($M7<VLOOKUP($A7, Mean_PE_S, 2, FALSE),1,0), IF(AND($M7>1,$M7<25),1,0))
```

### ZS Rank Columns:

#### P/FCF ZS Rank:
```
=IF($N7>0, "< 0 required", COUNTIFS($A:$A,$A7,$N:$N,"<0",$N:$N,"<="&$N7))
```
#### P/B ZS Rank:
```
=IF($O7>0, "< 0 required", COUNTIFS($A:$A,$A7,$O:$O,"<0",$O:$O,"<="&$O7))
```
#### ROE ZS Rank:
```
=IF($P7<0,"> 0 required",COUNTIFS($A:$A,$A7,$P:$P,">0",$P:$P,">="&$P7))
```
#### ROA ZS Rank:
```
=IF($Q7<0,"> 0 required",COUNTIFS($A:$A,$A7,$Q:$Q,">0",$Q:$Q,">="&$Q7))
```
#### A/E ZS Rank:
```
=IF($R7>0, "< 0 required", COUNTIFS($A:$A,$A7,$R:$R,"<0",$R:$R,"<="&$R7))
```
#### P/E ZS Rank:
```
=IF($S7>0, "< 0 required", COUNTIFS($A:$A,$A7,$S:$S,"<0",$S:$S,"<="&$S7))
```

### Summary Cells:

#### Number of stocks:
```
="Number of stocks: "&COUNTA($B$7:$B$1048576)
```
#### Max Score:
```
="Max Score:"&CHAR(10)&MAX($T$7:$T$1048576)&"/10"
```