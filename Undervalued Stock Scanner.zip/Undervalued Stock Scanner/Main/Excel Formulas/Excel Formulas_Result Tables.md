### Pull Data From Main Tables Based on Preliminary Criteria:

#### Result_L:
```
=FILTER(FILTER(Main_L, Main_L[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_L[#Headers]))
```
#### Result_M:
```
=FILTER(FILTER(Main_M, Main_M[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_M[#Headers]))
```
#### Result_S:
```
=FILTER(FILTER(Main_S, Main_S[Preliminary Criteria]="YES"), COUNTIF($A$6:$S$6,Main_S[#Headers]))
```

### Score Columns in Result Tables:

#### Result_L:
```
=SUM(IF($I8<(0.7*VLOOKUP($A8, Mean_PB_L, 2, FALSE)),1,0), IF($J8>VLOOKUP($A8, Mean_ROE_L, 2, FALSE),1,0), IF($K8>VLOOKUP($A8, Mean_ROA_L, 2,FALSE),1,0), IF($M8<VLOOKUP($A8, Mean_PE_L, 2, FALSE),1,0), IF(AND($M8>1,$M8<25),1,0))
```
#### Result_M:
```
=SUM(IF($I8<(0.7*VLOOKUP($A8, Mean_PB_L, 2, FALSE)),1,0), IF($J8>VLOOKUP($A8, Mean_ROE_M, 2, FALSE),1,0), IF($K8>VLOOKUP($A8, Mean_ROA_M, 2,FALSE),1,0), IF($M8<VLOOKUP($A8, Mean_PE_M, 2, FALSE),1,0), IF(AND($M8>1,$M8<25),1,0))
```
#### Result_S:
```
=SUM(IF($I8<(0.7*VLOOKUP($A8, Mean_PB_L, 2, FALSE)),1,0), IF($J8>VLOOKUP($A8, Mean_ROE_S, 2, FALSE),1,0), IF($K8>VLOOKUP($A8, Mean_ROA_S, 2,FALSE),1,0), IF($M8<VLOOKUP($A8, Mean_PE_S, 2, FALSE),1,0), IF(AND($M8>1,$M8<25),1,0))
```

### Summary Cells:

#### Number of stocks:
```
="Number of stocks: "&COUNTA($B$8:$B$1048576)
```
#### Max Score:
```
="Max Score:"&CHAR(10)&IFERROR(MAX($T$8:$T$1048576),0)&"/5"
```