### Power Query Code for Main_S table:
The dynamic path for **Undervalued Stock Scanner** folder is in the **DynamicPath** table, within the **Dynamic Path** sheet.  
**Quartile_S Function** is used to apply data transformation to a list of all csv files in **Downloaded CSV Files** folder. This creates **Quartile_S** tables for all sectors.
```m
let
    Source = Excel.CurrentWorkbook(){[Name="DynamicPath"]}[Content],
    Path = Source{0}[Path],
    Files = Folder.Files(Path & "Downloaded CSV Files"),
    #"Removed Other Columns" = Table.SelectColumns(Files,{"Name"}),
    #"Invoked Custom Function" = Table.AddColumn(#"Removed Other Columns", "Quartile_S Function", each #"Quartile_S Function"([Name])),
    #"Quartile_S Function1" = #"Invoked Custom Function"{0}[Quartile_S Function]
in
    #"Quartile_S Function1"
```
The **Quartile_S Function1** step expands one of the tables created by **Quartile_S Funtcion**. The expanded table in this code corresponds to **Builder Sample.csv**.  
To switch to another sector's **Quartile_S** table, undo the **Quartile_S Function1** step and choose another table corresponding to the desired sector.