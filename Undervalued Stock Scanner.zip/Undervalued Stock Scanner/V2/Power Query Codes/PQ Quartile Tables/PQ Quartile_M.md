### Power Query Code for Main_M table:
The dynamic path for **Undervalued Stock Scanner** folder is in the **DynamicPath** table, within the **Dynamic Path** sheet.  
**Quartile_M Function** is used to apply data transformation to a list of all csv files in **Downloaded CSV Files** folder. This creates **Quartile_M** tables for all sectors.
```m
let
    Source = Excel.CurrentWorkbook(){[Name="DynamicPath"]}[Content],
    Path = Source{0}[Path],
    Files = Folder.Files(Path & "Downloaded CSV Files"),
    #"Removed Other Columns" = Table.SelectColumns(Files,{"Name"}),
    #"Invoked Custom Function" = Table.AddColumn(#"Removed Other Columns", "Quartile_M Function", each #"Quartile_M Function"([Name])),
    #"Quartile_M Function1" = #"Invoked Custom Function"{0}[Quartile_M Function]
in
    #"Quartile_M Function1"
```
The **Quartile_M Function1** step expands one of the tables created by **Quartile_M Funtcion**. The expanded table in this code corresponds to **Builder Sample.csv**.  
To switch to another sector's **Quartile_M** table, undo the **Quartile_M Function1** step and choose another table corresponding to the desired sector.